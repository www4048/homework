//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// extendible_hash_table.cpp
//
// Identification: src/container/hash/extendible_hash_table.cpp
//
//===----------------------------------------------------------------------===//

#include <cassert>
#include <cstdlib>
#include <functional>
#include <list>
#include <utility>
#include <algorithm>

#include "container/hash/extendible_hash_table.h"
#include "storage/page/page.h"

namespace bustub {

// 构造函数：初始化一个空的哈希表，包含一个 bucket
template <typename K, typename V>
ExtendibleHashTable<K, V>::ExtendibleHashTable(size_t bucket_size)
    : global_depth_(0), bucket_size_(bucket_size), num_buckets_(1) {
  dir_.clear();
  dir_.resize(1);
  dir_[0] = std::make_shared<Bucket>(bucket_size_, 0);
}

// 根据 key 计算目录索引
template <typename K, typename V>
auto ExtendibleHashTable<K, V>::IndexOf(const K &key) -> size_t {
  if (global_depth_ == 0) {
    return 0;
  }
  size_t mask = (static_cast<size_t>(1) << global_depth_) - 1;
  return std::hash<K>()(key) & mask;
}

// 获取全局深度（带锁）
template <typename K, typename V>
auto ExtendibleHashTable<K, V>::GetGlobalDepth() const -> int {
  std::scoped_lock<std::mutex> lock(latch_);
  return GetGlobalDepthInternal();
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::GetGlobalDepthInternal() const -> int {
  return global_depth_;
}

// 获取局部深度（带锁）
template <typename K, typename V>
auto ExtendibleHashTable<K, V>::GetLocalDepth(int dir_index) const -> int {
  std::scoped_lock<std::mutex> lock(latch_);
  return GetLocalDepthInternal(dir_index);
}

// 获取局部深度（内部）
template <typename K, typename V>
auto ExtendibleHashTable<K, V>::GetLocalDepthInternal(int dir_index) const -> int {
  if (dir_index < 0 || static_cast<size_t>(dir_index) >= dir_.size()) {
    return -1;
  }
  auto bucket = dir_[dir_index];
  if (bucket == nullptr) {
    return -1;
  }
  return bucket->GetDepth();
}

// 获取桶数量（带锁）
template <typename K, typename V>
auto ExtendibleHashTable<K, V>::GetNumBuckets() const -> int {
  std::scoped_lock<std::mutex> lock(latch_);
  return GetNumBucketsInternal();
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::GetNumBucketsInternal() const -> int {
  return num_buckets_;
}

// 查找
template <typename K, typename V>
auto ExtendibleHashTable<K, V>::Find(const K &key, V &value) -> bool {
  std::scoped_lock<std::mutex> lock(latch_);
  if (dir_.empty()) return false;
  size_t idx = IndexOf(key);
  auto bucket = dir_[idx];
  if (bucket == nullptr) {
    return false;
  }
  return bucket->Find(key, value);
}

// 删除
template <typename K, typename V>
auto ExtendibleHashTable<K, V>::Remove(const K &key) -> bool {
  std::scoped_lock<std::mutex> lock(latch_);
  if (dir_.empty()) return false;
  size_t idx = IndexOf(key);
  auto bucket = dir_[idx];
  if (bucket == nullptr) {
    return false;
  }
  return bucket->Remove(key);
}

// 插入（支持自动 split）
template <typename K, typename V>
void ExtendibleHashTable<K, V>::Insert(const K &key, const V &value) {
  std::scoped_lock<std::mutex> lock(latch_);
  // 不断重试直到插入成功
  while (true) {
    size_t idx = IndexOf(key);
    auto bucket = dir_[idx];

    // 若 key 已存在，则更新
    V tmp;
    if (bucket->Find(key, tmp)) {
      for (auto &p : bucket->GetItems()) {
        if (p.first == key) {
          p.second = value;
          return;
        }
      }
    }

    // 桶未满则直接插入
    if (!bucket->IsFull()) {
      bucket->Insert(key, value);
      return;
    }

    // 桶满，需要 split
    int local_depth = bucket->GetDepth();

    // 若局部深度等于全局深度，先扩展目录
    if (local_depth == global_depth_) {
      size_t old_size = dir_.size();
      dir_.resize(old_size * 2);
      for (size_t i = 0; i < old_size; ++i) {
        dir_[i + old_size] = dir_[i];
      }
      global_depth_++;
    }

    // 创建新桶
    auto new_bucket = std::make_shared<Bucket>(bucket_size_, local_depth + 1);
    bucket->IncrementDepth();

    // 更新目录指针
    size_t dir_size = dir_.size();
    for (size_t i = 0; i < dir_size; ++i) {
      if (dir_[i] == bucket) {
        size_t bit = (i >> local_depth) & 1;
        if (bit == 1) {
          dir_[i] = new_bucket;
        }
      }
    }
    num_buckets_++;

    // 重分配原桶内数据
    std::list<std::pair<K, V>> old_items;
    old_items.splice(old_items.begin(), bucket->GetItems());
    for (auto &p : old_items) {
      size_t new_idx = IndexOf(p.first);
      dir_[new_idx]->Insert(p.first, p.second);
    }
    // 重试
  }
}

//===----------------------------------------------------------------------===//
// Bucket 实现
//===----------------------------------------------------------------------===//
template <typename K, typename V>
ExtendibleHashTable<K, V>::Bucket::Bucket(size_t array_size, int depth)
    : size_(array_size), depth_(depth) {}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::Bucket::Find(const K &key, V &value) -> bool {
  for (auto &p : list_) {
    if (p.first == key) {
      value = p.second;
      return true;
    }
  }
  return false;
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::Bucket::Remove(const K &key) -> bool {
  for (auto it = list_.begin(); it != list_.end(); ++it) {
    if (it->first == key) {
      list_.erase(it);
      return true;
    }
  }
  return false;
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::Bucket::Insert(const K &key, const V &value) -> bool {
  // 若已存在则更新
  for (auto &p : list_) {
    if (p.first == key) {
      p.second = value;
      return true;
    }
  }
  if (IsFull()) {
    return false;
  }
  list_.emplace_back(key, value);
  return true;
}

//===----------------------------------------------------------------------===//
// 显式模板实例化
//===----------------------------------------------------------------------===//
template class ExtendibleHashTable<page_id_t, Page *>;
template class ExtendibleHashTable<Page *, std::list<Page *>::iterator>;
template class ExtendibleHashTable<int, int>;
template class ExtendibleHashTable<int, std::string>;
template class ExtendibleHashTable<int, std::list<int>::iterator>;

}  // namespace bustub

