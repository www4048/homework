//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// lru_k_replacer.cpp
//
// Identification: src/buffer/lru_k_replacer.cpp
//
//===----------------------------------------------------------------------===//

#include "buffer/lru_k_replacer.h"
#include "common/exception.h"
#include "common/logger.h"

#include <algorithm>
#include <limits>

namespace bustub {

/**
 * LRU-K 替换器实现。
 * 算法要点：
 *  - 每个 frame 保存最近 k 次访问时间戳；
 *  - 如果访问次数 < k，则认为其“k 距离”为正无穷；
 *  - 驱逐规则：
 *     1. 先考虑访问次数 < k 的 frame，挑最早访问的；
 *     2. 否则挑第 k 次访问时间最早的。
 */

LRUKReplacer::LRUKReplacer(size_t num_frames, size_t k)
    : current_timestamp_(0), curr_size_(0), replacer_size_(num_frames), k_(k) {}

// 记录一次访问
void LRUKReplacer::RecordAccess(frame_id_t frame_id) {
  std::scoped_lock<std::mutex> lock(latch_);

  if (frame_id < 0 || static_cast<size_t>(frame_id) >= replacer_size_) {
    throw Exception("Invalid frame id in RecordAccess");
  }

  current_timestamp_++;

  // 获取或创建访问历史
  auto &hist = access_history_[frame_id];
  hist.push_back(current_timestamp_);
  if (hist.size() > k_) {
    hist.pop_front();  // 保留最近 k 次访问
  }

  // 如果之前没有记录可驱逐状态，初始化为 false
  if (evictable_.find(frame_id) == evictable_.end()) {
    evictable_[frame_id] = false;
  }
}

// 设置某个 frame 是否可驱逐
void LRUKReplacer::SetEvictable(frame_id_t frame_id, bool set_evictable) {
  std::scoped_lock<std::mutex> lock(latch_);

  if (frame_id < 0 || static_cast<size_t>(frame_id) >= replacer_size_) {
    throw Exception("Invalid frame id in SetEvictable");
  }

  // 如果该 frame 从未出现过，直接返回
  if (access_history_.find(frame_id) == access_history_.end()) {
    return;
  }

  bool was_evictable = evictable_[frame_id];
  evictable_[frame_id] = set_evictable;

  if (!was_evictable && set_evictable) {
    curr_size_++;
  } else if (was_evictable && !set_evictable) {
    curr_size_--;
  }
}

// 移除指定 frame
void LRUKReplacer::Remove(frame_id_t frame_id) {
  std::scoped_lock<std::mutex> lock(latch_);

  auto it = evictable_.find(frame_id);
  if (it == evictable_.end()) {
    return;
  }

  if (!it->second) {
    throw Exception("Attempt to remove a non-evictable frame");
  }

  evictable_.erase(frame_id);
  access_history_.erase(frame_id);
  curr_size_--;
}

// 选择 victim frame 驱逐
auto LRUKReplacer::Evict(frame_id_t *frame_id) -> bool {
  std::scoped_lock<std::mutex> lock(latch_);

  if (curr_size_ == 0) {
    return false;
  }

  bool found = false;
  size_t oldest_time = std::numeric_limits<size_t>::max();
  frame_id_t victim = -1;

  // 先优先考虑 < k 次访问的帧（Inf 情况）
  for (auto &[fid, hist] : access_history_) {
    if (!evictable_[fid]) {
      continue;
    }
    if (hist.size() < k_) {
      if (hist.front() < oldest_time) {
        oldest_time = hist.front();
        victim = fid;
        found = true;
      }
    }
  }

  // 如果没有 < k 的，选第 k 次访问时间最早的
  if (!found) {
    oldest_time = std::numeric_limits<size_t>::max();
    for (auto &[fid, hist] : access_history_) {
      if (!evictable_[fid]) {
        continue;
      }
      if (hist.size() >= k_) {
        size_t kth_time = hist.front();
        if (kth_time < oldest_time) {
          oldest_time = kth_time;
          victim = fid;
          found = true;
        }
      }
    }
  }

  if (!found) {
    return false;
  }

  // 从 replacer 中删除 victim
  evictable_.erase(victim);
  access_history_.erase(victim);
  curr_size_--;
  *frame_id = victim;
  return true;
}

// 返回当前可驱逐 frame 数
auto LRUKReplacer::Size() -> size_t {
  std::scoped_lock<std::mutex> lock(latch_);
  return curr_size_;
}

}  // namespace bustub

