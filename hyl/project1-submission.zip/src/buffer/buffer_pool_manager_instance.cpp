//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// buffer_pool_manager_instance.cpp
//
// Identification: src/buffer/buffer_pool_manager_instance.cpp
//
//===----------------------------------------------------------------------===//

#include "buffer/buffer_pool_manager_instance.h"

#include "common/exception.h"
#include "common/logger.h"
#include "common/macros.h"

namespace bustub {

BufferPoolManagerInstance::BufferPoolManagerInstance(size_t pool_size, DiskManager *disk_manager, size_t replacer_k,
                                                     LogManager *log_manager)
    : pool_size_(pool_size), disk_manager_(disk_manager), log_manager_(log_manager) {
  // allocate the buffer pool
  pages_ = new Page[pool_size_];

  // init page table and replacer
  page_table_ = new ExtendibleHashTable<page_id_t, frame_id_t>(bucket_size_);
  replacer_ = new LRUKReplacer(pool_size_, replacer_k);

  // initialize free list and page metadata
  for (size_t i = 0; i < pool_size_; ++i) {
    pages_[i].page_id_ = INVALID_PAGE_ID;
    pages_[i].pin_count_ = 0;
    pages_[i].is_dirty_ = false;
    free_list_.push_back(static_cast<int>(i));
  }
}

BufferPoolManagerInstance::~BufferPoolManagerInstance() {
  delete[] pages_;
  delete page_table_;
  delete replacer_;
}

/**
 * Allocate a new page in the buffer pool.
 * Returns pointer to Page, and sets *page_id to new id.
 * If no free frame and no replacer victim (all pinned), return nullptr.
 */
auto BufferPoolManagerInstance::NewPgImp(page_id_t *page_id) -> Page * {
  std::scoped_lock<std::mutex> lock(latch_);

  frame_id_t frame_id = -1;

  // choose a free frame first
  if (!free_list_.empty()) {
    frame_id = free_list_.front();
    free_list_.pop_front();
  } else {
    // otherwise ask replacer for a victim
    if (!replacer_->Evict(&frame_id)) {
      // no frame can be evicted
      return nullptr;
    }

    // victim frame: if dirty write back
    Page *victim = &pages_[frame_id];
    if (victim->IsDirty()) {
      disk_manager_->WritePage(victim->GetPageId(), victim->GetData());
      victim->is_dirty_ = false;
    }

    // remove old mapping
    page_table_->Remove(victim->GetPageId());
  }

  // allocate a new page id
  *page_id = AllocatePage();

  // initialize the frame
  Page *page = &pages_[frame_id];
  page->ResetMemory();
  page->page_id_ = *page_id;
  page->pin_count_ = 1;
  page->is_dirty_ = false;

  // update page table and replacer state
  page_table_->Insert(*page_id, frame_id);
  replacer_->RecordAccess(frame_id);
  replacer_->SetEvictable(frame_id, false);

  return page;
}

/**
 * Fetch a page into buffer pool (or return existing in-memory page).
 */
auto BufferPoolManagerInstance::FetchPgImp(page_id_t page_id) -> Page * {
  std::scoped_lock<std::mutex> lock(latch_);

  frame_id_t frame_id;
  // if page is already resident
  if (page_table_->Find(page_id, frame_id)) {
    Page *page = &pages_[frame_id];
    page->pin_count_++;
    replacer_->RecordAccess(frame_id);
    replacer_->SetEvictable(frame_id, false);
    return page;
  }

  // need to find a victim frame (free or replacer)
  if (!free_list_.empty()) {
    frame_id = free_list_.front();
    free_list_.pop_front();
  } else {
    if (!replacer_->Evict(&frame_id)) {
      return nullptr;  // no available frame
    }
    Page *victim = &pages_[frame_id];
    if (victim->IsDirty()) {
      disk_manager_->WritePage(victim->GetPageId(), victim->GetData());
      victim->is_dirty_ = false;
    }
    page_table_->Remove(victim->GetPageId());
  }

  // read page from disk
  Page *page = &pages_[frame_id];
  disk_manager_->ReadPage(page_id, page->GetData());
  page->page_id_ = page_id;
  page->pin_count_ = 1;
  page->is_dirty_ = false;

  // update page table and replacer
  page_table_->Insert(page_id, frame_id);
  replacer_->RecordAccess(frame_id);
  replacer_->SetEvictable(frame_id, false);

  return page;
}

/**
 * Unpin a page (decrement pin count). If pin_count reaches 0, make it evictable.
 */
auto BufferPoolManagerInstance::UnpinPgImp(page_id_t page_id, bool is_dirty) -> bool {
  std::scoped_lock<std::mutex> lock(latch_);

  frame_id_t frame_id;
  if (!page_table_->Find(page_id, frame_id)) {
    return false;
  }

  Page *page = &pages_[frame_id];
  if (page->pin_count_ <= 0) {
    return false;
  }

  page->pin_count_--;
  if (is_dirty) {
    page->is_dirty_ = true;
  }

  if (page->pin_count_ == 0) {
    replacer_->SetEvictable(frame_id, true);
  }

  return true;
}

/**
 * Flush a specific page to disk (regardless of dirty flag).
 */
auto BufferPoolManagerInstance::FlushPgImp(page_id_t page_id) -> bool {
  std::scoped_lock<std::mutex> lock(latch_);

  frame_id_t frame_id;
  if (!page_table_->Find(page_id, frame_id)) {
    return false;
  }

  Page *page = &pages_[frame_id];
  disk_manager_->WritePage(page_id, page->GetData());
  page->is_dirty_ = false;
  return true;
}

/**
 * Flush all pages in buffer pool to disk.
 */
void BufferPoolManagerInstance::FlushAllPgsImp() {
  std::scoped_lock<std::mutex> lock(latch_);
  for (size_t i = 0; i < pool_size_; ++i) {
    Page *page = &pages_[i];
    if (page->GetPageId() != INVALID_PAGE_ID && page->IsDirty()) {
      disk_manager_->WritePage(page->GetPageId(), page->GetData());
      page->is_dirty_ = false;
    }
  }
}

/**
 * Delete a page: if not in buffer pool, deallocate on disk and return true.
 * If in pool but pinned, return false.
 * Otherwise remove mapping, reset frame, put frame into free list and deallocate on disk.
 */
auto BufferPoolManagerInstance::DeletePgImp(page_id_t page_id) -> bool {
  std::scoped_lock<std::mutex> lock(latch_);

  frame_id_t frame_id;
  if (!page_table_->Find(page_id, frame_id)) {
    // not in buffer pool -> deallocate on disk
    DeallocatePage(page_id);
    return true;
  }

  Page *page = &pages_[frame_id];
  if (page->pin_count_ > 0) {
    return false;  // cannot delete pinned page
  }

  // remove from page table and replacer
  page_table_->Remove(page_id);
  // ensure replacer knows this frame is evictable, then remove
  try {
    replacer_->SetEvictable(frame_id, true);
    replacer_->Remove(frame_id);
  } catch (...) {
    // ignore errors from replacer remove
  }

  // reset page metadata and add frame to free list
  page->ResetMemory();
  page->page_id_ = INVALID_PAGE_ID;
  page->pin_count_ = 0;
  page->is_dirty_ = false;

  free_list_.push_back(frame_id);

  DeallocatePage(page_id);
  return true;
}

/**
 * Allocate a new page id (simple increment).
 */
auto BufferPoolManagerInstance::AllocatePage() -> page_id_t { return next_page_id_++; }

}  // namespace bustub

