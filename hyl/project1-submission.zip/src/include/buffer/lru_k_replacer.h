//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// lru_k_replacer.h
//
// Identification: src/include/buffer/lru_k_replacer.h
//
// Copyright (c)
// Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#pragma once

#include <deque>
#include <limits>
#include <mutex>  // NOLINT
#include <unordered_map>

#include "common/config.h"
#include "common/macros.h"

namespace bustub {

/**
 * LRU-K 替换策略（Least Recently Used - K）
 *
 * LRU-K 通过记录每个 frame 最近 K 次访问的时间戳来决定驱逐策略：
 * - 如果一个 frame 被访问不足 K 次，则认为其“k距离”为正无穷；
 * - 否则，它的 k 距离 = 当前时间戳 - 第 K 次前访问时间；
 * - 被驱逐的 frame 是：
 *    1. 所有 < K 次访问的 frame 中最早访问的；
 *    2. 否则是第 K 次访问最早的 frame。
 */
class LRUKReplacer {
 public:
  /**
   * @brief 构造函数
   * @param num_frames 可容纳的最大 frame 数量
   * @param k          LRU-K 算法参数（通常取 2）
   */
  explicit LRUKReplacer(size_t num_frames, size_t k);

  DISALLOW_COPY_AND_MOVE(LRUKReplacer);

  /** 默认析构函数 */
  ~LRUKReplacer() = default;

  /**
   * @brief 驱逐一个 frame（Evict victim）
   * @param[out] frame_id 被驱逐的 frame id
   * @return 是否成功驱逐
   */
  auto Evict(frame_id_t *frame_id) -> bool;

  /**
   * @brief 记录一次访问（更新时间戳）
   * @param frame_id 被访问的 frame id
   */
  void RecordAccess(frame_id_t frame_id);

  /**
   * @brief 设置某个 frame 是否可驱逐
   * @param frame_id 帧 id
   * @param set_evictable 是否设为可驱逐
   */
  void SetEvictable(frame_id_t frame_id, bool set_evictable);

  /**
   * @brief 删除一个可驱逐 frame（手动移除）
   * @param frame_id 被删除的 frame id
   */
  void Remove(frame_id_t frame_id);

  /**
   * @brief 返回当前可驱逐的 frame 数
   */
  auto Size() -> size_t;

 private:
  /**
   * 每个 frame 的访问历史：
   *   存储最近 k 次访问的时间戳（先进先出）
   */
  std::unordered_map<frame_id_t, std::deque<size_t>> access_history_;

  /**
   * 记录 frame 是否可驱逐
   */
  std::unordered_map<frame_id_t, bool> evictable_;

  /**
   * 当前全局时间戳（每次访问递增）
   */
  size_t current_timestamp_{0};

  /**
   * 当前可驱逐的 frame 数
   */
  size_t curr_size_{0};

  /**
   * Replacer 的总容量（最多可管理的 frame 数）
   */
  size_t replacer_size_;

  /**
   * LRU-K 参数 K
   */
  size_t k_;

  /**
   * 线程安全互斥锁
   */
  std::mutex latch_;
};

}  // namespace bustub

