//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// extendible_hash_table.cpp
//
// Identification: src/container/hash/extendible_hash_table.cpp
//
// Copyright (c) 2022, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include <cassert>
#include <cstdlib>
#include <functional>
#include <list>
#include <utility>

#include "container/hash/extendible_hash_table.h"
#include "storage/page/page.h"

namespace bustub {

template <typename K, typename V>
ExtendibleHashTable<K, V>::ExtendibleHashTable(size_t bucket_size) : bucket_size_(bucket_size) {
  dir_.push_back(std::make_shared<Bucket>(bucket_size_));
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::IndexOf(const K &key) -> size_t {
  int mask = (1 << global_depth_) - 1;
  return std::hash<K>()(key) & mask;
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::GetGlobalDepth() const -> int {
  std::scoped_lock<std::mutex> lock(latch_);
  return GetGlobalDepthInternal();
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::GetGlobalDepthInternal() const -> int {
  return global_depth_;
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::GetLocalDepth(int dir_index) const -> int {
  std::scoped_lock<std::mutex> lock(latch_);
  return GetLocalDepthInternal(dir_index);
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::GetLocalDepthInternal(int dir_index) const -> int {
  return dir_[dir_index]->GetDepth();
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::GetNumBuckets() const -> int {
  std::scoped_lock<std::mutex> lock(latch_);
  return GetNumBucketsInternal();
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::GetNumBucketsInternal() const -> int {
  return num_buckets_;
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::Find(const K &key, V &value) -> bool {
  std::scoped_lock<std::mutex> lock(latch_);
  size_t index = IndexOf(key);
  return dir_[index]->Find(key, value);
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::Remove(const K &key) -> bool {
  std::scoped_lock<std::mutex> lock(latch_);
  size_t index = IndexOf(key);
  return dir_[index]->Remove(key);
}

template <typename K, typename V>
void ExtendibleHashTable<K, V>::Insert(const K &key, const V &value) {
  std::scoped_lock<std::mutex> lock(latch_);
  
  size_t index = IndexOf(key);
  std::shared_ptr<Bucket> bucket = dir_[index];
  
  // If key exists, update the value
  if (bucket->Find(key, const_cast<V &>(value))) {
    bucket->Remove(key);
    bucket->Insert(key, value);
    return;
  }
  
  // If bucket is not full, insert directly
  if (!bucket->IsFull()) {
    bucket->Insert(key, value);
    return;
  }
  
  // Bucket is full, need to split
  while (bucket->IsFull()) {
    int local_depth = bucket->GetDepth();
    
    // If local depth equals global depth, increase global depth and expand directory
    if (local_depth == global_depth_) {
      int old_dir_size = dir_.size();
      global_depth_++;
      dir_.resize(2 * old_dir_size);
      
      // Point new directory entries to corresponding buckets
      for (int i = 0; i < old_dir_size; i++) {
        dir_[i + old_dir_size] = dir_[i];
      }
    }
    
    // Increase bucket's local depth
    bucket->IncrementDepth();
    local_depth = bucket->GetDepth();
    
    // Create new bucket
    auto new_bucket = std::make_shared<Bucket>(bucket_size_, local_depth);
    num_buckets_++;
    
    // Redistribute key-value pairs
    std::list<std::pair<K, V>> items = bucket->GetItems();
    bucket->GetItems().clear();
    
    for (const auto &item : items) {
      size_t new_index = IndexOf(item.first);
      if ((new_index >> (local_depth - 1)) & 1) {  // Check the bit at local depth position
        new_bucket->Insert(item.first, item.second);
      } else {
        bucket->Insert(item.first, item.second);
      }
    }
    
    // Update directory pointers
    for (size_t i = 0; i < dir_.size(); i++) {
      if (dir_[i] == bucket && ((i >> (local_depth - 1)) & 1)) {
        dir_[i] = new_bucket;
      }
    }
    
    // Recheck index to determine which bucket the key should be inserted into
    index = IndexOf(key);
    bucket = dir_[index];
  }
  
  bucket->Insert(key, value);
}

//===--------------------------------------------------------------------===//
// Bucket
//===--------------------------------------------------------------------===//
template <typename K, typename V>
ExtendibleHashTable<K, V>::Bucket::Bucket(size_t array_size, int depth) : size_(array_size), depth_(depth) {}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::Bucket::Find(const K &key, V &value) -> bool {
  for (auto &pair : list_) {
    if (pair.first == key) {
      value = pair.second;
      return true;
    }
  }
  return false;
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::Bucket::Remove(const K &key) -> bool {
  for (auto it = list_.begin(); it != list_.end(); ++it) {
    if (it->first == key) {
      list_.erase(it);
      return true;
    }
  }
  return false;
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::Bucket::Insert(const K &key, const V &value) -> bool {
  // If key exists, update the value
  for (auto &pair : list_) {
    if (pair.first == key) {
      pair.second = value;
      return true;
    }
  }
  
  // If bucket is not full, insert new key-value pair
  if (!IsFull()) {
    list_.emplace_back(key, value);
    return true;
  }
  
  // Bucket is full, cannot insert
  return false;
}

template class ExtendibleHashTable<page_id_t, Page *>;
template class ExtendibleHashTable<Page *, std::list<Page *>::iterator>;
template class ExtendibleHashTable<int, int>;
// test purpose
template class ExtendibleHashTable<int, std::string>;
template class ExtendibleHashTable<int, std::list<int>::iterator>;

}  // namespace bustub