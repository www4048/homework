//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// buffer_pool_manager_instance.cpp
//
// Identification: src/buffer/buffer_pool_manager.cpp
//
// Copyright (c) 2015-2021, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "buffer/buffer_pool_manager_instance.h"

#include "common/exception.h"
#include "common/macros.h"

namespace bustub {

BufferPoolManagerInstance::BufferPoolManagerInstance(size_t pool_size, DiskManager *disk_manager, size_t replacer_k,
                                                     LogManager *log_manager)
    : pool_size_(pool_size), disk_manager_(disk_manager), log_manager_(log_manager) {
  // we allocate a consecutive memory space for the buffer pool
  pages_ = new Page[pool_size_];
  page_table_ = new ExtendibleHashTable<page_id_t, frame_id_t>(bucket_size_);
  replacer_ = new LRUKReplacer(pool_size, replacer_k);

  // Initially, every page is in the free list.
  for (size_t i = 0; i < pool_size_; ++i) {
    free_list_.emplace_back(static_cast<int>(i));
  }

  // TODO(students): remove this line after you have implemented the buffer pool manager
  // throw NotImplementedException(
  //     "BufferPoolManager is not implemented yet. If you have finished implementing BPM, please remove the throw "
  //     "exception line in [buffer_pool_manager_instance.cpp](file:///Users/brianhsu/Desktop/bustub_initial/src/buffer/buffer_pool_manager_instance.cpp).");
}

BufferPoolManagerInstance::~BufferPoolManagerInstance() {
  delete[] pages_;
  delete page_table_;
  delete replacer_;
}

auto BufferPoolManagerInstance::NewPgImp(page_id_t *page_id) -> Page * {
  std::lock_guard<std::mutex> lock(latch_);
  
  frame_id_t frame_id;
  // Check the free list first
  if (!free_list_.empty()) {
    frame_id = free_list_.front();
    free_list_.pop_front();
  } else {
    // Try to evict a page from the replacer
    if (!replacer_->Evict(&frame_id)) {
      // No evictable frame available
      return nullptr;
    }
    
    // If the victim page is dirty, flush it to disk
    Page* victim_page = &pages_[frame_id];
    if (victim_page->IsDirty()) {
      disk_manager_->WritePage(victim_page->GetPageId(), victim_page->GetData());
    }
    
    // Remove the victim page from the page table
    page_table_->Remove(victim_page->GetPageId());
  }
  
  // Allocate a new page
  *page_id = AllocatePage();
  
  // Update page info
  Page* new_page = &pages_[frame_id];
  new_page->page_id_ = *page_id;
  new_page->pin_count_ = 1;
  new_page->is_dirty_ = false;
  new_page->ResetMemory();
  
  // Add to page table
  page_table_->Insert(*page_id, frame_id);
  
  // Record access and make it non-evictable
  replacer_->RecordAccess(frame_id);
  replacer_->SetEvictable(frame_id, false);
  
  return new_page;
}

auto BufferPoolManagerInstance::FetchPgImp(page_id_t page_id) -> Page * {
  std::lock_guard<std::mutex> lock(latch_);
  
  frame_id_t frame_id;
  // Check if the page is already in the buffer pool
  if (page_table_->Find(page_id, frame_id)) {
    // Page found in buffer pool
    Page* page = &pages_[frame_id];
    page->pin_count_++;
    replacer_->RecordAccess(frame_id);
    replacer_->SetEvictable(frame_id, false);
    return page;
  }
  
  // Page not in buffer pool, need to load it
  // Check the free list first
  if (!free_list_.empty()) {
    frame_id = free_list_.front();
    free_list_.pop_front();
  } else {
    // Try to evict a page from the replacer
    if (!replacer_->Evict(&frame_id)) {
      // No evictable frame available
      return nullptr;
    }
    
    // If the victim page is dirty, flush it to disk
    Page* victim_page = &pages_[frame_id];
    if (victim_page->IsDirty()) {
      disk_manager_->WritePage(victim_page->GetPageId(), victim_page->GetData());
    }
    
    // Remove the victim page from the page table
    page_table_->Remove(victim_page->GetPageId());
  }
  
  // Read page from disk
  Page* page = &pages_[frame_id];
  disk_manager_->ReadPage(page_id, page->data_);
  
  // Update page info
  page->page_id_ = page_id;
  page->pin_count_ = 1;
  page->is_dirty_ = false;
  
  // Add to page table
  page_table_->Insert(page_id, frame_id);
  
  // Record access and make it non-evictable
  replacer_->RecordAccess(frame_id);
  replacer_->SetEvictable(frame_id, false);
  
  return page;
}

auto BufferPoolManagerInstance::UnpinPgImp(page_id_t page_id, bool is_dirty) -> bool {
  std::lock_guard<std::mutex> lock(latch_);
  
  frame_id_t frame_id;
  if (!page_table_->Find(page_id, frame_id)) {
    // Page not in buffer pool
    return false;
  }
  
  Page* page = &pages_[frame_id];
  if (page->GetPinCount() <= 0) {
    // Pin count is already 0
    return false;
  }
  
  page->pin_count_--;
  if (is_dirty) {
    page->is_dirty_ = true;
  }
  
  // If pin count becomes 0, make it evictable
  if (page->GetPinCount() == 0) {
    replacer_->SetEvictable(frame_id, true);
  }
  
  return true;
}

auto BufferPoolManagerInstance::FlushPgImp(page_id_t page_id) -> bool {
  std::lock_guard<std::mutex> lock(latch_);
  
  if (page_id == INVALID_PAGE_ID) {
    return false;
  }
  
  frame_id_t frame_id;
  if (!page_table_->Find(page_id, frame_id)) {
    // Page not in buffer pool
    return false;
  }
  
  // Write page to disk regardless of dirty flag
  Page* page = &pages_[frame_id];
  disk_manager_->WritePage(page_id, page->GetData());
  
  // Clear dirty flag
  page->is_dirty_ = false;
  
  return true;
}

void BufferPoolManagerInstance::FlushAllPgsImp() {
  std::lock_guard<std::mutex> lock(latch_);
  
  for (size_t i = 0; i < pool_size_; i++) {
    page_id_t page_id = pages_[i].GetPageId();
    if (page_id != INVALID_PAGE_ID) {
      disk_manager_->WritePage(page_id, pages_[i].GetData());
      pages_[i].is_dirty_ = false;
    }
  }
}

auto BufferPoolManagerInstance::DeletePgImp(page_id_t page_id) -> bool {
  std::lock_guard<std::mutex> lock(latch_);
  
  frame_id_t frame_id;
  if (!page_table_->Find(page_id, frame_id)) {
    // Page not in buffer pool
    return true;
  }
  
  Page* page = &pages_[frame_id];
  if (page->GetPinCount() > 0) {
    // Page is pinned, cannot delete
    return false;
  }
  
  // If the page is dirty, flush it to disk
  if (page->IsDirty()) {
    disk_manager_->WritePage(page_id, page->GetData());
  }
  
  // Remove from page table
  page_table_->Remove(page_id);
  
  // Remove from replacer
  replacer_->Remove(frame_id);
  
  // Reset page metadata
  page->page_id_ = INVALID_PAGE_ID;
  page->pin_count_ = 0;
  page->is_dirty_ = false;
  page->ResetMemory();
  
  // Add frame back to free list
  free_list_.push_back(frame_id);
  
  // Deallocate page on disk
  DeallocatePage(page_id);
  
  return true;
}

auto BufferPoolManagerInstance::AllocatePage() -> page_id_t { return next_page_id_++; }

}  // namespace bustub