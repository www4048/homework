//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// lru_k_replacer.cpp
//
// Identification: src/buffer/lru_k_replacer.cpp
//
// Copyright (c) 2015-2022, Carnegie Mellon University Database Group
//
//===----------------------------------------------------------------------===//

#include "buffer/lru_k_replacer.h"
#include "common/exception.h"

namespace bustub {

LRUKReplacer::LRUKReplacer(size_t num_frames, size_t k) : replacer_size_(num_frames), k_(k) {}

auto LRUKReplacer::Evict(frame_id_t *frame_id) -> bool {
  std::lock_guard<std::mutex> lock(latch_);
  
  if (curr_size_ == 0) {
    return false;
  }
  
  // Find evictable frame with maximum backward k-distance
  auto max_it = frames_.end();
  size_t max_distance = 0;
  bool found_inf = false;
  auto inf_it = frames_.end();
  size_t earliest_timestamp = std::numeric_limits<size_t>::max();
  
  for (auto it = frames_.begin(); it != frames_.end(); ++it) {
    if (!it->second.evictable) {
      continue;
    }
    
    size_t distance = 0;
    bool has_inf = false;
    
    if (it->second.access_times.size() < k_) {
      // Less than k historical references, distance is infinity
      has_inf = true;
    } else {
      // Calculate backward k-distance
      distance = current_timestamp_ - it->second.access_times.front();
    }
    
    if (has_inf) {
      // For frames with infinite distance, pick the one with earliest timestamp
      if (!found_inf || it->second.access_times.front() < earliest_timestamp) {
        inf_it = it;
        earliest_timestamp = it->second.access_times.front();
      }
      found_inf = true;
    } else if (!found_inf) {
      // Only consider finite distances if no infinite ones found
      if (distance > max_distance) {
        max_distance = distance;
        max_it = it;
      }
    }
  }
  
  if (found_inf) {
    // Evict frame with infinite distance and earliest timestamp
    *frame_id = inf_it->first;
    frames_.erase(inf_it);
    curr_size_--;
    return true;
  }
  
  if (max_it != frames_.end()) {
    // Evict frame with maximum backward k-distance
    *frame_id = max_it->first;
    frames_.erase(max_it);
    curr_size_--;
    return true;
  }
  
  return false;
}

void LRUKReplacer::RecordAccess(frame_id_t frame_id) {
  std::lock_guard<std::mutex> lock(latch_);
  
  if (frame_id >= static_cast<int>(replacer_size_)) {
    throw Exception("Invalid frame_id");
  }
  
  current_timestamp_++;
  
  auto it = frames_.find(frame_id);
  if (it == frames_.end()) {
    // First access to this frame
    FrameInfo info;
    info.access_times.push_back(current_timestamp_);
    frames_[frame_id] = info;
  } else {
    // Existing frame
    it->second.access_times.push_back(current_timestamp_);
    // Keep only the last k_ access times
    if (it->second.access_times.size() > k_) {
      it->second.access_times.pop_front();
    }
  }
}

void LRUKReplacer::SetEvictable(frame_id_t frame_id, bool set_evictable) {
  std::lock_guard<std::mutex> lock(latch_);
  
  if (frame_id >= static_cast<int>(replacer_size_)) {
    throw Exception("Invalid frame_id");
  }
  
  auto it = frames_.find(frame_id);
  if (it == frames_.end()) {
    // Frame not found, nothing to do
    return;
  }
  
  if (it->second.evictable != set_evictable) {
    it->second.evictable = set_evictable;
    if (set_evictable) {
      curr_size_++;
    } else {
      curr_size_--;
    }
  }
}

void LRUKReplacer::Remove(frame_id_t frame_id) {
  std::lock_guard<std::mutex> lock(latch_);
  
  auto it = frames_.find(frame_id);
  if (it == frames_.end()) {
    // Frame not found, nothing to do
    return;
  }
  
  if (!it->second.evictable) {
    throw Exception("Cannot remove non-evictable frame");
  }
  
  frames_.erase(it);
  curr_size_--;
}

auto LRUKReplacer::Size() -> size_t {
  std::lock_guard<std::mutex> lock(latch_);
  return curr_size_;
}

}  // namespace bustub