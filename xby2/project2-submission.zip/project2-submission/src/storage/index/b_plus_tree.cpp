#include <string>

#include "common/exception.h"
#include "common/logger.h"
#include "common/rid.h"
#include "storage/index/b_plus_tree.h"
#include "storage/page/header_page.h"

namespace bustub {
INDEX_TEMPLATE_ARGUMENTS
BPLUSTREE_TYPE::BPlusTree(std::string name, BufferPoolManager *buffer_pool_manager, const KeyComparator &comparator,
                          int leaf_max_size, int internal_max_size)
    : index_name_(std::move(name)),
      root_page_id_(INVALID_PAGE_ID),
      buffer_pool_manager_(buffer_pool_manager),
      comparator_(comparator),
      leaf_max_size_(leaf_max_size),
      internal_max_size_(internal_max_size) {}

/*
 * Helper function to decide whether current b+tree is empty
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::IsEmpty() const -> bool { return root_page_id_ == INVALID_PAGE_ID; }
/*****************************************************************************
 * SEARCH
 *****************************************************************************/
/*
 * Return the only value that associated with input key
 * This method is used for point query
 * @return : true means key exists
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::GetValue(const KeyType &key, std::vector<ValueType> *result, Transaction *transaction) -> bool {
  root_latch_.RLock();
  if (IsEmpty()) {
    root_latch_.RUnlock();
    return false;
  }
  LeafPage *leaf_page = FindLeafPage(key, false, transaction);
  if (leaf_page == nullptr) {
    root_latch_.RUnlock();
    return false;
  }
  ValueType value;
  bool found = leaf_page->Lookup(key, &value, comparator_);
  // Unpin the leaf page
  buffer_pool_manager_->UnpinPage(leaf_page->GetPageId(), false);
  root_latch_.RUnlock();
  if (found) {
    result->push_back(value);
  }
  return found;
}

/*
 * Find leaf page containing the key
 * @param leftMost: if true, find the leftmost leaf page
 * @return: pointer to the leaf page
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::FindLeafPage(const KeyType &key, bool leftMost, Transaction *transaction) -> LeafPage * {
  Page *page = buffer_pool_manager_->FetchPage(root_page_id_);
  auto *node = reinterpret_cast<BPlusTreePage *>(page->GetData());

  while (!node->IsLeafPage()) {
    auto *internal_page = reinterpret_cast<InternalPage *>(node);
    page_id_t child_page_id;
    if (leftMost) {
      child_page_id = internal_page->ValueAt(0);
    } else {
      child_page_id = internal_page->Lookup(key, comparator_);
    }
    // Unpin current page and fetch child page
    buffer_pool_manager_->UnpinPage(node->GetPageId(), false);
    page = buffer_pool_manager_->FetchPage(child_page_id);
    node = reinterpret_cast<BPlusTreePage *>(page->GetData());
  }
  return reinterpret_cast<LeafPage *>(node);
}

/*****************************************************************************
 * INSERTION
 *****************************************************************************/
/*
 * Insert constant key & value pair into b+ tree
 * if current tree is empty, start new tree, update root page id and insert
 * entry, otherwise insert into leaf page.
 * @return: since we only support unique key, if user try to insert duplicate
 * keys return false, otherwise return true.
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::Insert(const KeyType &key, const ValueType &value, Transaction *transaction) -> bool {
  root_latch_.WLock();
  if (IsEmpty()) {
    StartNewTree(key, value);
    root_latch_.WUnlock();
    return true;
  }
  bool result = InsertIntoLeaf(key, value, transaction);
  root_latch_.WUnlock();
  return result;
}

/*
 * Start a new tree when inserting into an empty tree
 */
INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::StartNewTree(const KeyType &key, const ValueType &value) {
  // Create a new leaf page as root
  page_id_t new_page_id;
  Page *page = buffer_pool_manager_->NewPage(&new_page_id);
  auto *leaf_page = reinterpret_cast<LeafPage *>(page->GetData());
  leaf_page->Init(new_page_id, INVALID_PAGE_ID, leaf_max_size_);
  leaf_page->Insert(key, value, comparator_);
  root_page_id_ = new_page_id;
  UpdateRootPageId(1);
  buffer_pool_manager_->UnpinPage(new_page_id, true);
}

/*
 * Insert key-value pair into a leaf page
 * @return: true if inserted successfully, false if key already exists
 * Note: root_latch_ is already held by caller
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::InsertIntoLeaf(const KeyType &key, const ValueType &value, Transaction *transaction) -> bool {
  LeafPage *leaf_page = FindLeafPage(key, false, transaction);

  // Check if key already exists
  ValueType existing_value;
  if (leaf_page->Lookup(key, &existing_value, comparator_)) {
    buffer_pool_manager_->UnpinPage(leaf_page->GetPageId(), false);
    return false;
  }

  // Insert the key-value pair
  int size = leaf_page->Insert(key, value, comparator_);

  // Check if we need to split
  if (size >= leaf_max_size_) {
    // Split the leaf page
    LeafPage *new_leaf_page = Split(leaf_page);
    new_leaf_page->SetNextPageId(leaf_page->GetNextPageId());
    leaf_page->SetNextPageId(new_leaf_page->GetPageId());

    // Insert key into parent
    KeyType middle_key = new_leaf_page->KeyAt(0);
    InsertIntoParent(leaf_page, middle_key, new_leaf_page, transaction);
    buffer_pool_manager_->UnpinPage(new_leaf_page->GetPageId(), true);
  }

  buffer_pool_manager_->UnpinPage(leaf_page->GetPageId(), true);
  return true;
}

/*
 * Split a full leaf or internal page
 * @return: newly created page after split
 */
INDEX_TEMPLATE_ARGUMENTS
template <typename N>
auto BPLUSTREE_TYPE::Split(N *node) -> N * {
  page_id_t new_page_id;
  Page *new_page = buffer_pool_manager_->NewPage(&new_page_id);
  auto *new_node = reinterpret_cast<N *>(new_page->GetData());

  if (node->IsLeafPage()) {
    auto *leaf = reinterpret_cast<LeafPage *>(node);
    auto *new_leaf = reinterpret_cast<LeafPage *>(new_node);
    new_leaf->Init(new_page_id, leaf->GetParentPageId(), leaf_max_size_);
    leaf->MoveHalfTo(new_leaf);
  } else {
    auto *internal = reinterpret_cast<InternalPage *>(node);
    auto *new_internal = reinterpret_cast<InternalPage *>(new_node);
    new_internal->Init(new_page_id, internal->GetParentPageId(), internal_max_size_);
    internal->MoveHalfTo(new_internal, buffer_pool_manager_);
  }

  return new_node;
}

/*
 * Insert key into parent internal node after splitting child node
 */
INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::InsertIntoParent(BPlusTreePage *old_node, const KeyType &key, BPlusTreePage *new_node,
                                      Transaction *transaction) {
  // If old_node is root, create a new root
  if (old_node->IsRootPage()) {
    page_id_t new_root_id;
    Page *new_root_page = buffer_pool_manager_->NewPage(&new_root_id);
    auto *new_root = reinterpret_cast<InternalPage *>(new_root_page->GetData());
    new_root->Init(new_root_id, INVALID_PAGE_ID, internal_max_size_);
    new_root->PopulateNewRoot(old_node->GetPageId(), key, new_node->GetPageId());

    old_node->SetParentPageId(new_root_id);
    new_node->SetParentPageId(new_root_id);

    root_page_id_ = new_root_id;
    UpdateRootPageId(0);
    buffer_pool_manager_->UnpinPage(new_root_id, true);
    return;
  }

  // Get parent page
  page_id_t parent_id = old_node->GetParentPageId();
  Page *parent_page = buffer_pool_manager_->FetchPage(parent_id);
  auto *parent = reinterpret_cast<InternalPage *>(parent_page->GetData());

  // Insert new key into parent
  new_node->SetParentPageId(parent_id);
  int size = parent->InsertNodeAfter(old_node->GetPageId(), key, new_node->GetPageId());

  // Check if parent needs to split
  if (size >= internal_max_size_) {
    InternalPage *new_parent = Split(parent);
    KeyType middle_key = new_parent->KeyAt(0);
    InsertIntoParent(parent, middle_key, new_parent, transaction);
    buffer_pool_manager_->UnpinPage(new_parent->GetPageId(), true);
  }

  buffer_pool_manager_->UnpinPage(parent_id, true);
}

/*****************************************************************************
 * REMOVE
 *****************************************************************************/
/*
 * Delete key & value pair associated with input key
 * If current tree is empty, return immediately.
 * If not, User needs to first find the right leaf page as deletion target, then
 * delete entry from leaf page. Remember to deal with redistribute or merge if
 * necessary.
 */
INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::Remove(const KeyType &key, Transaction *transaction) {
  root_latch_.WLock();
  if (IsEmpty()) {
    root_latch_.WUnlock();
    return;
  }

  LeafPage *leaf_page = FindLeafPage(key, false, transaction);

  int old_size = leaf_page->GetSize();
  int new_size = leaf_page->RemoveAndDeleteRecord(key, comparator_);

  // Key not found
  if (old_size == new_size) {
    buffer_pool_manager_->UnpinPage(leaf_page->GetPageId(), false);
    root_latch_.WUnlock();
    return;
  }

  // Check if underflow
  bool should_delete = CoalesceOrRedistribute(leaf_page, transaction);
  buffer_pool_manager_->UnpinPage(leaf_page->GetPageId(), true);

  if (should_delete) {
    buffer_pool_manager_->DeletePage(leaf_page->GetPageId());
  }

  root_latch_.WUnlock();
}

/*
 * Handle underflow of a node after deletion
 * @return: true if the node should be deleted
 */
INDEX_TEMPLATE_ARGUMENTS
template <typename N>
auto BPLUSTREE_TYPE::CoalesceOrRedistribute(N *node, Transaction *transaction) -> bool {
  // Root page special case
  if (node->IsRootPage()) {
    return AdjustRoot(node);
  }

  // Check if node is at minimum size
  if (node->GetSize() >= node->GetMinSize()) {
    return false;
  }

  // Get parent page
  Page *parent_page = buffer_pool_manager_->FetchPage(node->GetParentPageId());
  auto *parent = reinterpret_cast<InternalPage *>(parent_page->GetData());

  // Find node's index in parent
  int index = parent->ValueIndex(node->GetPageId());

  // Try to borrow from neighbor (prefer left neighbor)
  page_id_t neighbor_page_id;
  if (index == 0) {
    // No left neighbor, use right neighbor
    neighbor_page_id = parent->ValueAt(1);
  } else {
    // Use left neighbor
    neighbor_page_id = parent->ValueAt(index - 1);
  }

  Page *neighbor_page = buffer_pool_manager_->FetchPage(neighbor_page_id);
  auto *neighbor = reinterpret_cast<N *>(neighbor_page->GetData());

  // Check if we can redistribute
  if (neighbor->GetSize() > neighbor->GetMinSize()) {
    // Redistribute
    Redistribute(neighbor, node, index);
    buffer_pool_manager_->UnpinPage(neighbor_page_id, true);
    buffer_pool_manager_->UnpinPage(parent->GetPageId(), true);
    return false;
  }

  // Coalesce
  bool should_delete_parent = Coalesce(&neighbor, &node, &parent, index, transaction);
  buffer_pool_manager_->UnpinPage(neighbor_page_id, true);
  buffer_pool_manager_->UnpinPage(parent->GetPageId(), true);

  if (should_delete_parent) {
    buffer_pool_manager_->DeletePage(parent->GetPageId());
  }

  return true;
}

/*
 * Coalesce two nodes: merge node into neighbor
 * @param neighbor_node: the left neighbor (or right if node is first child)
 * @param node: the node to be deleted
 * @param parent: parent of the nodes
 * @param index: index of node in parent
 * @return: true if parent should be deleted
 */
INDEX_TEMPLATE_ARGUMENTS
template <typename N>
auto BPLUSTREE_TYPE::Coalesce(N **neighbor_node, N **node, InternalPage **parent, int index,
                               Transaction *transaction) -> bool {
  // Make sure neighbor is on the left
  if (index == 0) {
    // Node is the first child, swap so neighbor is still "left"
    std::swap(*neighbor_node, *node);
    index = 1;
  }

  KeyType middle_key = (*parent)->KeyAt(index);

  if ((*node)->IsLeafPage()) {
    auto *leaf = reinterpret_cast<LeafPage *>(*node);
    auto *neighbor_leaf = reinterpret_cast<LeafPage *>(*neighbor_node);
    leaf->MoveAllTo(neighbor_leaf);
  } else {
    auto *internal = reinterpret_cast<InternalPage *>(*node);
    auto *neighbor_internal = reinterpret_cast<InternalPage *>(*neighbor_node);
    internal->MoveAllTo(neighbor_internal, middle_key, buffer_pool_manager_);
  }

  // Remove key from parent
  (*parent)->Remove(index);

  // Check if parent underflows
  return CoalesceOrRedistribute(*parent, transaction);
}

/*
 * Redistribute: borrow one entry from neighbor
 * @param neighbor_node: neighbor node
 * @param node: underflowing node
 * @param index: index of node in parent (0 means node is first child)
 */
INDEX_TEMPLATE_ARGUMENTS
template <typename N>
void BPLUSTREE_TYPE::Redistribute(N *neighbor_node, N *node, int index) {
  Page *parent_page = buffer_pool_manager_->FetchPage(node->GetParentPageId());
  auto *parent = reinterpret_cast<InternalPage *>(parent_page->GetData());

  if (node->IsLeafPage()) {
    auto *leaf = reinterpret_cast<LeafPage *>(node);
    auto *neighbor_leaf = reinterpret_cast<LeafPage *>(neighbor_node);

    if (index == 0) {
      // Borrow from right neighbor (neighbor is on the right)
      neighbor_leaf->MoveFirstToEndOf(leaf);
      // Update parent key
      parent->SetKeyAt(1, neighbor_leaf->KeyAt(0));
    } else {
      // Borrow from left neighbor (neighbor is on the left)
      neighbor_leaf->MoveLastToFrontOf(leaf);
      // Update parent key
      parent->SetKeyAt(index, leaf->KeyAt(0));
    }
  } else {
    auto *internal = reinterpret_cast<InternalPage *>(node);
    auto *neighbor_internal = reinterpret_cast<InternalPage *>(neighbor_node);

    if (index == 0) {
      // Borrow from right neighbor
      KeyType middle_key = parent->KeyAt(1);
      neighbor_internal->MoveFirstToEndOf(internal, middle_key, buffer_pool_manager_);
      parent->SetKeyAt(1, neighbor_internal->KeyAt(0));
    } else {
      // Borrow from left neighbor
      KeyType middle_key = parent->KeyAt(index);
      neighbor_internal->MoveLastToFrontOf(internal, middle_key, buffer_pool_manager_);
      parent->SetKeyAt(index, internal->KeyAt(0));
    }
  }

  buffer_pool_manager_->UnpinPage(parent->GetPageId(), true);
}

/*
 * Adjust root when it becomes empty or has only one child
 * @return: true if old root should be deleted
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::AdjustRoot(BPlusTreePage *old_root_node) -> bool {
  // Case 1: root is leaf and has no more entries
  if (old_root_node->IsLeafPage() && old_root_node->GetSize() == 0) {
    root_page_id_ = INVALID_PAGE_ID;
    UpdateRootPageId(0);
    return true;
  }

  // Case 2: root is internal and has only one child
  if (!old_root_node->IsLeafPage() && old_root_node->GetSize() == 1) {
    auto *root = reinterpret_cast<InternalPage *>(old_root_node);
    page_id_t new_root_id = root->RemoveAndReturnOnlyChild();

    // Update new root's parent
    Page *new_root_page = buffer_pool_manager_->FetchPage(new_root_id);
    auto *new_root = reinterpret_cast<BPlusTreePage *>(new_root_page->GetData());
    new_root->SetParentPageId(INVALID_PAGE_ID);
    buffer_pool_manager_->UnpinPage(new_root_id, true);

    root_page_id_ = new_root_id;
    UpdateRootPageId(0);
    return true;
  }

  return false;
}

/*****************************************************************************
 * INDEX ITERATOR
 *****************************************************************************/
/*
 * Input parameter is void, find the leftmost leaf page first, then construct
 * index iterator
 * @return : index iterator
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::Begin() -> INDEXITERATOR_TYPE {
  root_latch_.RLock();
  if (IsEmpty()) {
    root_latch_.RUnlock();
    return INDEXITERATOR_TYPE();
  }
  LeafPage *leaf_page = FindLeafPage(KeyType(), true, nullptr);
  root_latch_.RUnlock();
  return INDEXITERATOR_TYPE(buffer_pool_manager_, leaf_page, 0);
}

/*
 * Input parameter is low key, find the leaf page that contains the input key
 * first, then construct index iterator
 * @return : index iterator
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::Begin(const KeyType &key) -> INDEXITERATOR_TYPE {
  root_latch_.RLock();
  if (IsEmpty()) {
    root_latch_.RUnlock();
    return INDEXITERATOR_TYPE();  // 返回空迭代器
  }
  
  LeafPage *leaf_page = FindLeafPage(key, false, nullptr);
  root_latch_.RUnlock();
  
  // 安全检查：FindLeafPage 可能失败
  if (leaf_page == nullptr) {
    return INDEXITERATOR_TYPE();
  }
  
  // Find the index of the key in the leaf page
  int index = 0;
  for (; index < leaf_page->GetSize(); index++) {
    if (comparator_(leaf_page->KeyAt(index), key) >= 0) {
      break;
    }
  }
  
  // If index exceeds size, we need to move to next page or return end
  if (index >= leaf_page->GetSize()) {
    page_id_t next_page_id = leaf_page->GetNextPageId();
    buffer_pool_manager_->UnpinPage(leaf_page->GetPageId(), false);
    
    if (next_page_id == INVALID_PAGE_ID) {
      return INDEXITERATOR_TYPE();
    }
    
    Page *next_page = buffer_pool_manager_->FetchPage(next_page_id);
    if (next_page == nullptr) {
      return INDEXITERATOR_TYPE();
    }
    
    leaf_page = reinterpret_cast<LeafPage *>(next_page->GetData());
    index = 0;
  }
  
  // 注意：迭代器会管理页面的 pin/unpin
  return INDEXITERATOR_TYPE(buffer_pool_manager_, leaf_page, index);
}

/*
 * Input parameter is void, construct an index iterator representing the end
 * of the key/value pair in the leaf node
 * @return : index iterator
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::End() -> INDEXITERATOR_TYPE { return INDEXITERATOR_TYPE(); }

/**
 * @return Page id of the root of this tree
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::GetRootPageId() -> page_id_t { return root_page_id_; }

/*****************************************************************************
 * UTILITIES AND DEBUG
 *****************************************************************************/
/*
 * Update/Insert root page id in header page(where page_id = 0, header_page is
 * defined under include/page/header_page.h)
 * Call this method everytime root page id is changed.
 * @parameter: insert_record      default value is false. When set to true,
 * insert a record <index_name, root_page_id> into header page instead of
 * updating it.
 */
INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::UpdateRootPageId(int insert_record) {
  auto *header_page = static_cast<HeaderPage *>(buffer_pool_manager_->FetchPage(HEADER_PAGE_ID));
  if (insert_record != 0) {
    // create a new record<index_name + root_page_id> in header_page
    header_page->InsertRecord(index_name_, root_page_id_);
  } else {
    // update root_page_id in header_page
    header_page->UpdateRecord(index_name_, root_page_id_);
  }
  buffer_pool_manager_->UnpinPage(HEADER_PAGE_ID, true);
}

/*
 * This method is used for test only
 * Read data from file and insert one by one
 */
INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::InsertFromFile(const std::string &file_name, Transaction *transaction) {
  int64_t key;
  std::ifstream input(file_name);
  while (input) {
    input >> key;

    KeyType index_key;
    index_key.SetFromInteger(key);
    RID rid(key);
    Insert(index_key, rid, transaction);
  }
}
/*
 * This method is used for test only
 * Read data from file and remove one by one
 */
INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::RemoveFromFile(const std::string &file_name, Transaction *transaction) {
  int64_t key;
  std::ifstream input(file_name);
  while (input) {
    input >> key;
    KeyType index_key;
    index_key.SetFromInteger(key);
    Remove(index_key, transaction);
  }
}

/**
 * This method is used for debug only, You don't need to modify
 */
INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::Draw(BufferPoolManager *bpm, const std::string &outf) {
  if (IsEmpty()) {
    LOG_WARN("Draw an empty tree");
    return;
  }
  std::ofstream out(outf);
  out << "digraph G {" << std::endl;
  ToGraph(reinterpret_cast<BPlusTreePage *>(bpm->FetchPage(root_page_id_)->GetData()), bpm, out);
  out << "}" << std::endl;
  out.flush();
  out.close();
}

/**
 * This method is used for debug only, You don't need to modify
 */
INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::Print(BufferPoolManager *bpm) {
  if (IsEmpty()) {
    LOG_WARN("Print an empty tree");
    return;
  }
  ToString(reinterpret_cast<BPlusTreePage *>(bpm->FetchPage(root_page_id_)->GetData()), bpm);
}

/**
 * This method is used for debug only, You don't need to modify
 * @tparam KeyType
 * @tparam ValueType
 * @tparam KeyComparator
 * @param page
 * @param bpm
 * @param out
 */
INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::ToGraph(BPlusTreePage *page, BufferPoolManager *bpm, std::ofstream &out) const {
  std::string leaf_prefix("LEAF_");
  std::string internal_prefix("INT_");
  if (page->IsLeafPage()) {
    auto *leaf = reinterpret_cast<LeafPage *>(page);
    // Print node name
    out << leaf_prefix << leaf->GetPageId();
    // Print node properties
    out << "[shape=plain color=green ";
    // Print data of the node
    out << "label=<<TABLE BORDER=\"0\" CELLBORDER=\"1\" CELLSPACING=\"0\" CELLPADDING=\"4\">\n";
    // Print data
    out << "<TR><TD COLSPAN=\"" << leaf->GetSize() << "\">P=" << leaf->GetPageId() << "</TD></TR>\n";
    out << "<TR><TD COLSPAN=\"" << leaf->GetSize() << "\">"
        << "max_size=" << leaf->GetMaxSize() << ",min_size=" << leaf->GetMinSize() << ",size=" << leaf->GetSize()
        << "</TD></TR>\n";
    out << "<TR>";
    for (int i = 0; i < leaf->GetSize(); i++) {
      out << "<TD>" << leaf->KeyAt(i) << "</TD>\n";
    }
    out << "</TR>";
    // Print table end
    out << "</TABLE>>];\n";
    // Print Leaf node link if there is a next page
    if (leaf->GetNextPageId() != INVALID_PAGE_ID) {
      out << leaf_prefix << leaf->GetPageId() << " -> " << leaf_prefix << leaf->GetNextPageId() << ";\n";
      out << "{rank=same " << leaf_prefix << leaf->GetPageId() << " " << leaf_prefix << leaf->GetNextPageId() << "};\n";
    }

    // Print parent links if there is a parent
    if (leaf->GetParentPageId() != INVALID_PAGE_ID) {
      out << internal_prefix << leaf->GetParentPageId() << ":p" << leaf->GetPageId() << " -> " << leaf_prefix
          << leaf->GetPageId() << ";\n";
    }
  } else {
    auto *inner = reinterpret_cast<InternalPage *>(page);
    // Print node name
    out << internal_prefix << inner->GetPageId();
    // Print node properties
    out << "[shape=plain color=pink ";  // why not?
    // Print data of the node
    out << "label=<<TABLE BORDER=\"0\" CELLBORDER=\"1\" CELLSPACING=\"0\" CELLPADDING=\"4\">\n";
    // Print data
    out << "<TR><TD COLSPAN=\"" << inner->GetSize() << "\">P=" << inner->GetPageId() << "</TD></TR>\n";
    out << "<TR><TD COLSPAN=\"" << inner->GetSize() << "\">"
        << "max_size=" << inner->GetMaxSize() << ",min_size=" << inner->GetMinSize() << ",size=" << inner->GetSize()
        << "</TD></TR>\n";
    out << "<TR>";
    for (int i = 0; i < inner->GetSize(); i++) {
      out << "<TD PORT=\"p" << inner->ValueAt(i) << "\">";
      if (i > 0) {
        out << inner->KeyAt(i);
      } else {
        out << " ";
      }
      out << "</TD>\n";
    }
    out << "</TR>";
    // Print table end
    out << "</TABLE>>];\n";
    // Print Parent link
    if (inner->GetParentPageId() != INVALID_PAGE_ID) {
      out << internal_prefix << inner->GetParentPageId() << ":p" << inner->GetPageId() << " -> " << internal_prefix
          << inner->GetPageId() << ";\n";
    }
    // Print leaves
    for (int i = 0; i < inner->GetSize(); i++) {
      auto child_page = reinterpret_cast<BPlusTreePage *>(bpm->FetchPage(inner->ValueAt(i))->GetData());
      ToGraph(child_page, bpm, out);
      if (i > 0) {
        auto sibling_page = reinterpret_cast<BPlusTreePage *>(bpm->FetchPage(inner->ValueAt(i - 1))->GetData());
        if (!sibling_page->IsLeafPage() && !child_page->IsLeafPage()) {
          out << "{rank=same " << internal_prefix << sibling_page->GetPageId() << " " << internal_prefix
              << child_page->GetPageId() << "};\n";
        }
        bpm->UnpinPage(sibling_page->GetPageId(), false);
      }
    }
  }
  bpm->UnpinPage(page->GetPageId(), false);
}

/**
 * This function is for debug only, you don't need to modify
 * @tparam KeyType
 * @tparam ValueType
 * @tparam KeyComparator
 * @param page
 * @param bpm
 */
INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::ToString(BPlusTreePage *page, BufferPoolManager *bpm) const {
  if (page->IsLeafPage()) {
    auto *leaf = reinterpret_cast<LeafPage *>(page);
    std::cout << "Leaf Page: " << leaf->GetPageId() << " parent: " << leaf->GetParentPageId()
              << " next: " << leaf->GetNextPageId() << std::endl;
    for (int i = 0; i < leaf->GetSize(); i++) {
      std::cout << leaf->KeyAt(i) << ",";
    }
    std::cout << std::endl;
    std::cout << std::endl;
  } else {
    auto *internal = reinterpret_cast<InternalPage *>(page);
    std::cout << "Internal Page: " << internal->GetPageId() << " parent: " << internal->GetParentPageId() << std::endl;
    for (int i = 0; i < internal->GetSize(); i++) {
      std::cout << internal->KeyAt(i) << ": " << internal->ValueAt(i) << ",";
    }
    std::cout << std::endl;
    std::cout << std::endl;
    for (int i = 0; i < internal->GetSize(); i++) {
      ToString(reinterpret_cast<BPlusTreePage *>(bpm->FetchPage(internal->ValueAt(i))->GetData()), bpm);
    }
  }
  bpm->UnpinPage(page->GetPageId(), false);
}

/*****************************************************************************
 * CONCURRENT CONTROL HELPERS
 *****************************************************************************/

/*
 * Find leaf page with latch crabbing
 * @param op: the operation type (SEARCH, INSERT, DELETE)
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::FindLeafPageWithOp(const KeyType &key, Operation op, Transaction *transaction, bool leftMost)
    -> LeafPage * {
  // Acquire appropriate latch on root
  if (op == Operation::SEARCH) {
    root_latch_.RLock();
  } else {
    root_latch_.WLock();
  }

  if (IsEmpty()) {
    if (op == Operation::SEARCH) {
      root_latch_.RUnlock();
    } else {
      root_latch_.WUnlock();
    }
    return nullptr;
  }

  Page *page = buffer_pool_manager_->FetchPage(root_page_id_);
  auto *node = reinterpret_cast<BPlusTreePage *>(page->GetData());

  // Acquire latch on root page
  if (op == Operation::SEARCH) {
    page->RLatch();
    root_latch_.RUnlock();
  } else {
    page->WLatch();
    if (transaction != nullptr) {
      transaction->AddIntoPageSet(page);
    }
  }

  while (!node->IsLeafPage()) {
    auto *internal_page = reinterpret_cast<InternalPage *>(node);
    page_id_t child_page_id;

    if (leftMost) {
      child_page_id = internal_page->ValueAt(0);
    } else {
      child_page_id = internal_page->Lookup(key, comparator_);
    }

    Page *child_page = buffer_pool_manager_->FetchPage(child_page_id);
    auto *child_node = reinterpret_cast<BPlusTreePage *>(child_page->GetData());

    if (op == Operation::SEARCH) {
      child_page->RLatch();
      page->RUnlatch();
      buffer_pool_manager_->UnpinPage(page->GetPageId(), false);
    } else {
      child_page->WLatch();
      // Check if child is safe
      if (IsSafe(child_node, op)) {
        // Release all latches on ancestors
        if (transaction != nullptr) {
          UnlockUnpinPages(transaction);
        }
        root_latch_.WUnlock();
      }
      if (transaction != nullptr) {
        transaction->AddIntoPageSet(child_page);
      }
    }

    page = child_page;
    node = child_node;
  }

  return reinterpret_cast<LeafPage *>(node);
}

/*
 * Check if a node is safe for the given operation
 * Safe means the operation won't cause split (for insert) or merge (for delete)
 */
INDEX_TEMPLATE_ARGUMENTS
auto BPLUSTREE_TYPE::IsSafe(BPlusTreePage *node, Operation op) -> bool {
  if (op == Operation::INSERT) {
    // Safe if won't overflow after insertion
    if (node->IsLeafPage()) {
      return node->GetSize() < leaf_max_size_ - 1;
    }
    return node->GetSize() < internal_max_size_ - 1;
  }
  if (op == Operation::DELETE) {
    // Safe if won't underflow after deletion
    if (node->IsRootPage()) {
      if (node->IsLeafPage()) {
        return node->GetSize() > 1;
      }
      return node->GetSize() > 2;
    }
    return node->GetSize() > node->GetMinSize();
  }
  return true;
}

/*
 * Release all write latches and unpin pages held in transaction's page set
 */
INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::UnlockUnpinPages(Transaction *transaction) {
  if (transaction == nullptr) {
    return;
  }
  auto page_set = transaction->GetPageSet();
  while (!page_set->empty()) {
    Page *page = page_set->front();
    page_set->pop_front();
    page->WUnlatch();
    buffer_pool_manager_->UnpinPage(page->GetPageId(), true);
  }
}

/*
 * Release all write latches on pages (without unpinning)
 */
INDEX_TEMPLATE_ARGUMENTS
void BPLUSTREE_TYPE::UnlockPages(Transaction *transaction) {
  if (transaction == nullptr) {
    return;
  }
  auto page_set = transaction->GetPageSet();
  for (auto *page : *page_set) {
    page->WUnlatch();
  }
  page_set->clear();
}

template class BPlusTree<GenericKey<4>, RID, GenericComparator<4>>;
template class BPlusTree<GenericKey<8>, RID, GenericComparator<8>>;
template class BPlusTree<GenericKey<16>, RID, GenericComparator<16>>;
template class BPlusTree<GenericKey<32>, RID, GenericComparator<32>>;
template class BPlusTree<GenericKey<64>, RID, GenericComparator<64>>;

}  // namespace bustub
