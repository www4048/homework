/**
 * index_iterator.cpp
 */
#include <cassert>

#include "storage/index/index_iterator.h"

namespace bustub {

/*
 * NOTE: you can change the destructor/constructor method here
 * set your own input parameters
 */
INDEX_TEMPLATE_ARGUMENTS
INDEXITERATOR_TYPE::IndexIterator() : buffer_pool_manager_(nullptr), leaf_page_(nullptr), index_(0) {}

INDEX_TEMPLATE_ARGUMENTS
INDEXITERATOR_TYPE::IndexIterator(BufferPoolManager *bpm, LeafPage *leaf, int index)
    : buffer_pool_manager_(bpm), leaf_page_(leaf), index_(index) {}

INDEX_TEMPLATE_ARGUMENTS
INDEXITERATOR_TYPE::~IndexIterator() {
  if (leaf_page_ != nullptr) {
    buffer_pool_manager_->UnpinPage(leaf_page_->GetPageId(), false);
  }
}  // NOLINT

INDEX_TEMPLATE_ARGUMENTS
INDEXITERATOR_TYPE::IndexIterator(IndexIterator &&other) noexcept
    : buffer_pool_manager_(other.buffer_pool_manager_), leaf_page_(other.leaf_page_), index_(other.index_) {
  other.leaf_page_ = nullptr;
}

INDEX_TEMPLATE_ARGUMENTS
auto INDEXITERATOR_TYPE::operator=(IndexIterator &&other) noexcept -> INDEXITERATOR_TYPE & {
  if (this != &other) {
    if (leaf_page_ != nullptr) {
      buffer_pool_manager_->UnpinPage(leaf_page_->GetPageId(), false);
    }
    buffer_pool_manager_ = other.buffer_pool_manager_;
    leaf_page_ = other.leaf_page_;
    index_ = other.index_;
    other.leaf_page_ = nullptr;
  }
  return *this;
}

INDEX_TEMPLATE_ARGUMENTS
auto INDEXITERATOR_TYPE::IsEnd() -> bool { 
  // 修复：检查是否是有效的结束位置
  if (leaf_page_ == nullptr) {
    return true;
  }
  
  // 检查是否在当前页面的末尾且没有下一页
  if (index_ >= leaf_page_->GetSize() && leaf_page_->GetNextPageId() == INVALID_PAGE_ID) {
    return true;
  }
  
  return false;
}

INDEX_TEMPLATE_ARGUMENTS
auto INDEXITERATOR_TYPE::operator*() -> const MappingType & {
  if (leaf_page_ == nullptr || index_ >= leaf_page_->GetSize()) {
    throw Exception("Index iterator out of bounds");
  }
  return leaf_page_->GetItem(index_);
}

INDEX_TEMPLATE_ARGUMENTS
auto INDEXITERATOR_TYPE::operator++() -> INDEXITERATOR_TYPE & {
  if (leaf_page_ == nullptr) {
    return *this;
  }
  
  index_++;
  
  // 如果超出当前页面，移动到下一页
  if (index_ >= leaf_page_->GetSize()) {
    page_id_t next_page_id = leaf_page_->GetNextPageId();
    
    // 释放当前页面
    if (leaf_page_ != nullptr) {
      buffer_pool_manager_->UnpinPage(leaf_page_->GetPageId(), false);
    }
    
    if (next_page_id == INVALID_PAGE_ID) {
      // 没有下一页，迭代器结束
      leaf_page_ = nullptr;
      index_ = 0;
    } else {
      // 获取下一页
      Page *next_page = buffer_pool_manager_->FetchPage(next_page_id);
      leaf_page_ = reinterpret_cast<LeafPage *>(next_page->GetData());
      index_ = 0;
    }
  }
  
  return *this;
}

INDEX_TEMPLATE_ARGUMENTS
auto INDEXITERATOR_TYPE::operator==(const IndexIterator &itr) const -> bool {
  // 两个都是结束迭代器
  if (leaf_page_ == nullptr && itr.leaf_page_ == nullptr) {
    return true;
  }
  
  // 一个结束一个没结束
  if (leaf_page_ == nullptr || itr.leaf_page_ == nullptr) {
    return false;
  }
  
  // 比较页面和索引
  return leaf_page_->GetPageId() == itr.leaf_page_->GetPageId() && index_ == itr.index_;
}

INDEX_TEMPLATE_ARGUMENTS
auto INDEXITERATOR_TYPE::operator!=(const IndexIterator &itr) const -> bool {
  return !(*this == itr);
}

template class IndexIterator<GenericKey<4>, RID, GenericComparator<4>>;
template class IndexIterator<GenericKey<8>, RID, GenericComparator<8>>;
template class IndexIterator<GenericKey<16>, RID, GenericComparator<16>>;
template class IndexIterator<GenericKey<32>, RID, GenericComparator<32>>;
template class IndexIterator<GenericKey<64>, RID, GenericComparator<64>>;

}  // namespace bustub
