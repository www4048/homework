//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// buffer_pool_manager_instance.cpp
//
//===----------------------------------------------------------------------===//

#include "buffer/buffer_pool_manager_instance.h"
#include "common/exception.h"

namespace bustub {

BufferPoolManagerInstance::BufferPoolManagerInstance(size_t pool_size, DiskManager *disk_manager, size_t replacer_k,
                                                     LogManager *log_manager)
    : pool_size_(pool_size), disk_manager_(disk_manager), log_manager_(log_manager) {
  pages_ = new Page[pool_size_];
  page_table_ = new ExtendibleHashTable<page_id_t, frame_id_t>(bucket_size_);
  replacer_ = new LRUKReplacer(pool_size_, replacer_k);

  for (size_t i = 0; i < pool_size_; ++i) {
    free_list_.emplace_back(static_cast<int>(i));
  }
}

BufferPoolManagerInstance::~BufferPoolManagerInstance() {
  delete[] pages_;
  delete page_table_;
  delete replacer_;
}

// Allocate a new page
auto BufferPoolManagerInstance::NewPgImp(page_id_t *page_id) -> Page * {
  std::lock_guard lock(latch_);
  frame_id_t frame_id;

  if (!free_list_.empty()) {
    frame_id = free_list_.front();
    free_list_.pop_front();
  } else if (!replacer_->Evict(&frame_id)) {
    return nullptr;
  } else {
    auto *victim = &pages_[frame_id];
    if (victim->IsDirty()) {
      disk_manager_->WritePage(victim->GetPageId(), victim->GetData());
    }
    page_table_->Remove(victim->GetPageId());
  }

  *page_id = AllocatePage();
  auto *page = &pages_[frame_id];
  page->page_id_ = *page_id;
  page->pin_count_ = 1;
  page->is_dirty_ = false;
  page->ResetMemory();

  page_table_->Insert(*page_id, frame_id);
  replacer_->RecordAccess(frame_id);
  replacer_->SetEvictable(frame_id, false);
  return page;
}

// Fetch an existing page
auto BufferPoolManagerInstance::FetchPgImp(page_id_t page_id) -> Page * {
  std::lock_guard lock(latch_);
  frame_id_t frame_id;

  if (page_table_->Find(page_id, frame_id)) {
    auto *page = &pages_[frame_id];
    page->pin_count_++;
    replacer_->RecordAccess(frame_id);
    replacer_->SetEvictable(frame_id, false);
    return page;
  }

  if (!free_list_.empty()) {
    frame_id = free_list_.front();
    free_list_.pop_front();
  } else if (!replacer_->Evict(&frame_id)) {
    return nullptr;
  } else {
    auto *victim = &pages_[frame_id];
    if (victim->IsDirty()) {
      disk_manager_->WritePage(victim->GetPageId(), victim->GetData());
    }
    page_table_->Remove(victim->GetPageId());
  }

  auto *page = &pages_[frame_id];
  disk_manager_->ReadPage(page_id, page->data_);
  page->page_id_ = page_id;
  page->pin_count_ = 1;
  page->is_dirty_ = false;

  page_table_->Insert(page_id, frame_id);
  replacer_->RecordAccess(frame_id);
  replacer_->SetEvictable(frame_id, false);
  return page;
}

// Unpin a page
auto BufferPoolManagerInstance::UnpinPgImp(page_id_t page_id, bool is_dirty) -> bool {
  std::lock_guard lock(latch_);
  frame_id_t frame_id;

  if (!page_table_->Find(page_id, frame_id)) return false;

  auto *page = &pages_[frame_id];
  if (page->GetPinCount() <= 0) return false;

  page->pin_count_--;
  if (is_dirty) page->is_dirty_ = true;
  if (page->GetPinCount() == 0) replacer_->SetEvictable(frame_id, true);

  return true;
}

// Flush a single page
auto BufferPoolManagerInstance::FlushPgImp(page_id_t page_id) -> bool {
  std::lock_guard lock(latch_);
  if (page_id == INVALID_PAGE_ID) return false;

  frame_id_t frame_id;
  if (!page_table_->Find(page_id, frame_id)) return false;

  auto *page = &pages_[frame_id];
  disk_manager_->WritePage(page_id, page->GetData());
  page->is_dirty_ = false;
  return true;
}

// Flush all pages
void BufferPoolManagerInstance::FlushAllPgsImp() {
  std::lock_guard lock(latch_);
  for (size_t i = 0; i < pool_size_; ++i) {
    auto &page = pages_[i];
    if (page.GetPageId() != INVALID_PAGE_ID) {
      disk_manager_->WritePage(page.GetPageId(), page.GetData());
      page.is_dirty_ = false;
    }
  }
}

// Delete a page
auto BufferPoolManagerInstance::DeletePgImp(page_id_t page_id) -> bool {
  std::lock_guard lock(latch_);
  frame_id_t frame_id;

  if (!page_table_->Find(page_id, frame_id)) return true;

  auto *page = &pages_[frame_id];
  if (page->GetPinCount() > 0) return false;

  if (page->IsDirty()) disk_manager_->WritePage(page_id, page->GetData());

  page_table_->Remove(page_id);
  replacer_->Remove(frame_id);

  page->page_id_ = INVALID_PAGE_ID;
  page->pin_count_ = 0;
  page->is_dirty_ = false;
  page->ResetMemory();

  free_list_.push_back(frame_id);
  DeallocatePage(page_id);
  return true;
}

// Allocate a new page id
auto BufferPoolManagerInstance::AllocatePage() -> page_id_t { return next_page_id_++; }

}  // namespace bustub

