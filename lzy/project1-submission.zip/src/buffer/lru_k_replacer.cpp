//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// lru_k_replacer.cpp
//
//===----------------------------------------------------------------------===//

#include "buffer/lru_k_replacer.h"
#include "common/exception.h"

namespace bustub {

LRUKReplacer::LRUKReplacer(size_t num_frames, size_t k) : replacer_size_(num_frames), k_(k) {}

auto LRUKReplacer::Evict(frame_id_t *frame_id) -> bool {
  std::lock_guard lock(latch_);
  if (curr_size_ == 0) return false;

  auto max_it = frames_.end();
  size_t max_dist = 0;
  bool found_inf = false;
  auto inf_it = frames_.end();
  size_t earliest_ts = std::numeric_limits<size_t>::max();

  for (auto it = frames_.begin(); it != frames_.end(); ++it) {
    auto &info = it->second;
    if (!info.evictable) continue;

    const bool has_inf = info.access_times.size() < k_;
    const size_t dist = has_inf ? 0 : current_timestamp_ - info.access_times.front();

    if (has_inf) {
      if (!found_inf || info.access_times.front() < earliest_ts) {
        inf_it = it;
        earliest_ts = info.access_times.front();
      }
      found_inf = true;
    } else if (!found_inf && dist > max_dist) {
      max_dist = dist;
      max_it = it;
    }
  }

  if (found_inf) {
    *frame_id = inf_it->first;
    frames_.erase(inf_it);
    --curr_size_;
    return true;
  }

  if (max_it != frames_.end()) {
    *frame_id = max_it->first;
    frames_.erase(max_it);
    --curr_size_;
    return true;
  }

  return false;
}

void LRUKReplacer::RecordAccess(frame_id_t frame_id) {
  std::lock_guard lock(latch_);
  if (frame_id >= static_cast<int>(replacer_size_)) throw Exception("Invalid frame_id");

  ++current_timestamp_;
  auto &info = frames_[frame_id];  // default-construct if not exist
  info.access_times.push_back(current_timestamp_);
  if (info.access_times.size() > k_) info.access_times.pop_front();
}

void LRUKReplacer::SetEvictable(frame_id_t frame_id, bool evictable) {
  std::lock_guard lock(latch_);
  if (frame_id >= static_cast<int>(replacer_size_)) throw Exception("Invalid frame_id");

  auto it = frames_.find(frame_id);
  if (it == frames_.end()) return;

  if (it->second.evictable != evictable) {
    it->second.evictable = evictable;
    curr_size_ += evictable ? 1 : -1;
  }
}

void LRUKReplacer::Remove(frame_id_t frame_id) {
  std::lock_guard lock(latch_);
  auto it = frames_.find(frame_id);
  if (it == frames_.end()) return;
  if (!it->second.evictable) throw Exception("Cannot remove non-evictable frame");

  frames_.erase(it);
  --curr_size_;
}

auto LRUKReplacer::Size() -> size_t {
  std::lock_guard lock(latch_);
  return curr_size_;
}

}  // namespace bustub

