//===----------------------------------------------------------------------===//
//
//                         BusTub
//
// extendible_hash_table.cpp
//
// Identification: src/container/hash/extendible_hash_table.cpp
//
//===----------------------------------------------------------------------===//

#include <cassert>
#include <functional>
#include <list>
#include <memory>
#include <mutex>
#include <utility>
#include <vector>

#include "container/hash/extendible_hash_table.h"
#include "storage/page/page.h"

namespace bustub {

template <typename K, typename V>
ExtendibleHashTable<K, V>::ExtendibleHashTable(size_t bucket_size)
    : bucket_size_(bucket_size) {
  dir_.emplace_back(std::make_shared<Bucket>(bucket_size_));
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::IndexOf(const K &key) -> size_t {
  const int mask = (1 << global_depth_) - 1;
  return std::hash<K>()(key) & mask;
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::GetGlobalDepth() const -> int {
  std::scoped_lock lock(latch_);
  return global_depth_;
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::GetLocalDepth(int dir_index) const -> int {
  std::scoped_lock lock(latch_);
  return dir_[dir_index]->GetDepth();
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::GetNumBuckets() const -> int {
  std::scoped_lock lock(latch_);
  return num_buckets_;
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::Find(const K &key, V &value) -> bool {
  std::scoped_lock lock(latch_);
  return dir_[IndexOf(key)]->Find(key, value);
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::Remove(const K &key) -> bool {
  std::scoped_lock lock(latch_);
  return dir_[IndexOf(key)]->Remove(key);
}

template <typename K, typename V>
void ExtendibleHashTable<K, V>::Insert(const K &key, const V &value) {
  std::scoped_lock lock(latch_);
  auto idx = IndexOf(key);
  auto bucket = dir_[idx];

  // update existing key
  if (bucket->Find(key, const_cast<V &>(value))) {
    bucket->Remove(key);
    bucket->Insert(key, value);
    return;
  }

  // insert directly if space
  if (!bucket->IsFull()) {
    bucket->Insert(key, value);
    return;
  }

  // handle bucket splits
  while (bucket->IsFull()) {
    auto local_depth = bucket->GetDepth();

    if (local_depth == global_depth_) {
      const auto old_size = dir_.size();
      global_depth_++;
      dir_.resize(2 * old_size);
      for (size_t i = 0; i < old_size; ++i) {
        dir_[i + old_size] = dir_[i];
      }
    }

    bucket->IncrementDepth();
    local_depth = bucket->GetDepth();

    auto new_bucket = std::make_shared<Bucket>(bucket_size_, local_depth);
    num_buckets_++;

    auto items = bucket->GetItems();
    bucket->GetItems().clear();

    for (auto &&[k, v] : items) {
      const auto new_idx = IndexOf(k);
      if ((new_idx >> (local_depth - 1)) & 1) {
        new_bucket->Insert(k, v);
      } else {
        bucket->Insert(k, v);
      }
    }

    for (size_t i = 0; i < dir_.size(); ++i) {
      if (dir_[i] == bucket && ((i >> (local_depth - 1)) & 1)) {
        dir_[i] = new_bucket;
      }
    }

    idx = IndexOf(key);
    bucket = dir_[idx];
  }

  bucket->Insert(key, value);
}

//===----------------------------------------------------------------------===//
// Bucket
//===----------------------------------------------------------------------===//
template <typename K, typename V>
ExtendibleHashTable<K, V>::Bucket::Bucket(size_t capacity, int depth)
    : size_(capacity), depth_(depth) {}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::Bucket::Find(const K &key, V &value) -> bool {
  for (auto &&[k, v] : list_) {
    if (k == key) {
      value = v;
      return true;
    }
  }
  return false;
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::Bucket::Remove(const K &key) -> bool {
  for (auto it = list_.begin(); it != list_.end(); ++it) {
    if (it->first == key) {
      list_.erase(it);
      return true;
    }
  }
  return false;
}

template <typename K, typename V>
auto ExtendibleHashTable<K, V>::Bucket::Insert(const K &key, const V &value) -> bool {
  for (auto &&[k, v] : list_) {
    if (k == key) {
      v = value;
      return true;
    }
  }
  if (!IsFull()) {
    list_.emplace_back(key, value);
    return true;
  }
  return false;
}

// explicit instantiations
template class ExtendibleHashTable<page_id_t, Page *>;
template class ExtendibleHashTable<Page *, std::list<Page *>::iterator>;
template class ExtendibleHashTable<int, int>;
template class ExtendibleHashTable<int, std::string>;
template class ExtendibleHashTable<int, std::list<int>::iterator>;

}  // namespace bustub

